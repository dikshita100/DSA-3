// ============================================
// WORD-LEVEL PLAGIARISM CHECKER
// ============================================

// Reference documents
const REFERENCE_CORPUS = [
    {
        id: "REF001",
        title: "Academic Machine Learning Document",
        text: `
            Machine learning allows computers to learn from data without
            being explicitly programmed. It is widely used in education,
            healthcare, finance and many other fields.
        `
    },

    {
        id: "REF002",
        title: "Artificial Intelligence Research Paper",
        text: `
            Artificial intelligence enables machines to perform tasks that
            normally require human intelligence. These tasks include learning,
            reasoning, problem solving and decision making.
        `
    },

    {
        id: "REF003",
        title: "Student Technology Assignment",
        text: `
            Technology has changed the way students learn and communicate.
            Online learning platforms provide students with access to
            educational resources from different locations.
        `
    }
];


// ============================================
// 1. NORMALIZE TEXT
// ============================================

function normalizeText(text) {

    return text
        .toLowerCase()
        .replace(/[^\p{L}\p{N}\s]/gu, " ")
        .replace(/\s+/g, " ")
        .trim();
}


// ============================================
// 2. SPLIT TEXT INTO WORDS
// ============================================

function tokenize(text) {

    const normalizedText = normalizeText(text);

    if (normalizedText.length === 0) {
        return [];
    }

    return normalizedText.split(" ");
}


// ============================================
// 3. CREATE WORD GROUPS
// ============================================

function createNGrams(words, size) {

    const ngrams = [];

    for (let i = 0; i <= words.length - size; i++) {

        const phrase = words
            .slice(i, i + size)
            .join(" ");

        ngrams.push(phrase);
    }

    return ngrams;
}


// ============================================
// 4. FIND EXACT MATCHES
// ============================================

function findExactMatches(inputWords, referenceWords) {

    // Compare groups of 4 consecutive words
    const phraseSize = 4;

    const inputPhrases =
        createNGrams(inputWords, phraseSize);

    const referencePhrases =
        new Set(
            createNGrams(referenceWords, phraseSize)
        );

    const matches = [];

    inputPhrases.forEach(phrase => {

        if (referencePhrases.has(phrase)) {

            if (!matches.includes(phrase)) {
                matches.push(phrase);
            }
        }
    });

    return matches;
}


// ============================================
// 5. CALCULATE JACCARD SIMILARITY
// ============================================

function calculateJaccard(words1, words2) {

    const set1 = new Set(words1);
    const set2 = new Set(words2);

    const intersection = new Set(
        [...set1].filter(word => set2.has(word))
    );

    const union = new Set(
        [...set1, ...set2]
    );

    if (union.size === 0) {
        return 0;
    }

    return intersection.size / union.size;
}


// ============================================
// 6. ANALYZE DOCUMENT
// ============================================

function analyzeDocument(inputText) {

    const inputWords = tokenize(inputText);

    // If no text was entered
    if (inputWords.length === 0) {

        return {
            similarity: 0,
            original: 100,
            exact: 0,
            reworded: 0,
            reordered: 0,
            wordsAnalyzed: 0,
            sources: [],
            exactMatches: []
        };
    }


    let exactScore = 0;
    let rewordedScore = 0;
    let reorderedScore = 0;

    const sources = [];
    let allExactMatches = [];


    // ========================================
    // Compare with every reference document
    // ========================================

    REFERENCE_CORPUS.forEach(reference => {

        const referenceWords =
            tokenize(reference.text);


        // --------------------------------------
        // Exact phrase matching
        // --------------------------------------

        const exactMatches =
            findExactMatches(
                inputWords,
                referenceWords
            );


        let exactPercentage = 0;


        if (exactMatches.length > 0) {

            const matchedWords =
                exactMatches.length * 4;

            exactPercentage =
                (matchedWords /
                    inputWords.length) * 100;
        }


        // --------------------------------------
        // Word similarity
        // --------------------------------------

        const jaccard =
            calculateJaccard(
                inputWords,
                referenceWords
            );


        const lexicalPercentage =
            jaccard * 100;


        // --------------------------------------
        // Classify the match
        // --------------------------------------

        let sourcePercentage = 0;
        let matchType = "Original";


        if (exactPercentage >= 5) {

            sourcePercentage =
                exactPercentage;

            matchType =
                "Exact Match";

            exactScore +=
                exactPercentage;
        }


        else if (lexicalPercentage >= 35) {

            sourcePercentage =
                lexicalPercentage;

            matchType =
                "Reworded";

            rewordedScore +=
                lexicalPercentage;
        }


        else if (lexicalPercentage >= 20) {

            sourcePercentage =
                lexicalPercentage;

            matchType =
                "Reordered";

            reorderedScore +=
                lexicalPercentage;
        }


        // --------------------------------------
        // Save matching source
        // --------------------------------------

        if (sourcePercentage > 0) {

            sources.push({

                id: reference.id,

                title: reference.title,

                percentage:
                    Math.round(sourcePercentage),

                type: matchType
            });
        }


        allExactMatches =
            allExactMatches.concat(
                exactMatches
            );
    });


    // ========================================
    // Limit values to 100
    // ========================================

    exactScore =
        Math.min(exactScore, 100);

    rewordedScore =
        Math.min(rewordedScore, 100);

    reorderedScore =
        Math.min(reorderedScore, 100);


    // ========================================
    // Overall similarity
    // ========================================

    let similarity =
        exactScore +
        (rewordedScore * 0.6) +
        (reorderedScore * 0.4);


    similarity =
        Math.min(
            Math.round(similarity),
            100
        );


    // ========================================
    // Original percentage
    // ========================================

    const original =
        Math.max(
            0,
            100 - similarity
        );


    // ========================================
    // Return result
    // ========================================

    return {

        similarity: similarity,

        original: original,

        exact: Math.round(
            Math.min(
                exactScore,
                similarity
            )
        ),

        reworded: Math.round(
            Math.min(
                rewordedScore,
                similarity
            )
        ),

        reordered: Math.round(
            Math.min(
                reorderedScore,
                similarity
            )
        ),

        wordsAnalyzed:
            inputWords.length,

        sources: sources,

        exactMatches: [
            ...new Set(
                allExactMatches
            )
        ]
    };
}