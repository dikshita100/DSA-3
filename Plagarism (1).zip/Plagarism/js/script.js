document.addEventListener("DOMContentLoaded", function () {

    /* =========================
       REGISTER
       ========================= */

    const registerForm =
        document.getElementById("registerForm");

    if (registerForm) {

        registerForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                const nameInput =
                    document.getElementById("registerName");

                const emailInput =
                    document.getElementById("registerEmail");

                const passwordInput =
                    document.getElementById("registerPassword");

                const confirmPasswordInput =
                    document.getElementById("confirmPassword");


                /* Make sure fields exist */

                if (
                    !nameInput ||
                    !emailInput ||
                    !passwordInput ||
                    !confirmPasswordInput
                ) {

                    alert(
                        "Registration form fields are missing."
                    );

                    return;
                }


                /* Get values */

                const name =
                    nameInput.value.trim();

                const email =
                    emailInput.value
                        .trim()
                        .toLowerCase();

                const password =
                    passwordInput.value;

                const confirmPassword =
                    confirmPasswordInput.value;


                /* Empty fields */

                if (
                    !name ||
                    !email ||
                    !password ||
                    !confirmPassword
                ) {

                    alert(
                        "Please fill in all fields."
                    );

                    return;
                }


                /* Password length */

                if (password.length < 6) {

                    alert(
                        "Password must contain at least 6 characters."
                    );

                    return;
                }


                /* Password confirmation */

                if (password !== confirmPassword) {

                    alert(
                        "Passwords do not match."
                    );

                    return;
                }


                /* Check whether account already exists */

                const existingUser =
                    localStorage.getItem(
                        "registeredUser"
                    );


                if (existingUser) {

                    try {

                        const user =
                            JSON.parse(existingUser);

                        if (
                            user.email &&
                            user.email
                                .trim()
                                .toLowerCase() === email
                        ) {

                            alert(
                                "An account with this email already exists."
                            );

                            window.location.href =
                                "login.html";

                            return;
                        }

                    } catch (error) {

                        console.log(
                            "Invalid old account data."
                        );

                        localStorage.removeItem(
                            "registeredUser"
                        );
                    }
                }


                /* Create new account */

                const newUser = {

                    name: name,

                    email: email,

                    password: password,

                    registeredAt:
                        new Date().toISOString()

                };


                /* Save account */

                localStorage.setItem(
                    "registeredUser",
                    JSON.stringify(newUser)
                );


                /* Success message */

                alert(
                    "Account created successfully! You can now login."
                );


                /* Go to login */

                window.location.href =
                    "login.html";

            }
        );
    }



    /* =========================
       LOGIN
    ========================= */

    const loginForm =
        document.getElementById("loginForm");

    if (loginForm) {

        loginForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                const emailInput =
                    document.getElementById("email");

                const passwordInput =
                    document.getElementById("password");

                const rememberMe =
                    document.getElementById("rememberMe");

                const email =
                    emailInput.value
                        .trim()
                        .toLowerCase();

                const password =
                    passwordInput.value;


                /* Get registered user */

                const registeredUser =
                    JSON.parse(
                        localStorage.getItem(
                            "registeredUser"
                        )
                    );


                /* No registered account */

                if (!registeredUser) {

                    alert(
                        "No account found. Please create an account first."
                    );

                    return;
                }


                /* Check login details */

                const savedEmail =
                    String(
                        registeredUser.email || ""
                    )
                    .trim()
                    .toLowerCase();

                const savedPassword =
                    String(
                        registeredUser.password || ""
                    );


                if (
                    email === savedEmail &&
                    password === savedPassword
                ) {

                    /* Save logged-in user */

                    const loggedInUser = {

                        name:
                            registeredUser.name ||
                            "User",

                        email:
                            registeredUser.email,

                        loginTime:
                            new Date().toISOString()

                    };


                    localStorage.setItem(
                        "loggedInUser",
                        JSON.stringify(loggedInUser)
                    );


                    /* Remember email */

                    if (
                        rememberMe &&
                        rememberMe.checked
                    ) {

                        localStorage.setItem(
                            "rememberedEmail",
                            email
                        );

                    } else {

                        localStorage.removeItem(
                            "rememberedEmail"
                        );

                    }


                    /* Go to dashboard */

                    window.location.href =
                        "dashboard.html";


                } else {

                    alert(
                        "Incorrect email or password."
                    );

                }

            }
        );
    }



    /* =========================
       REMEMBERED EMAIL
    ========================= */

    const emailInput =
        document.getElementById("email");

    const rememberMe =
        document.getElementById("rememberMe");


    if (
        emailInput &&
        rememberMe
    ) {

        const rememberedEmail =
            localStorage.getItem(
                "rememberedEmail"
            );


        if (rememberedEmail) {

            emailInput.value =
                rememberedEmail;

            rememberMe.checked =
                true;

        }

    }



    /* =========================
       FORGOT PASSWORD
    ========================= */

    const forgotPassword =
        document.getElementById(
            "forgotPassword"
        );


    if (forgotPassword) {

        forgotPassword.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                alert(
                    "Password reset functionality can be added here."
                );

            }
        );

    }

});