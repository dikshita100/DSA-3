from pymongo import MongoClient

MONGO_URL = "mongodb://localhost:27017/"

client = MongoClient(MONGO_URL)

db = client["plagiarism_db"]

reference_collection = db["reference_documents"]

try:
    client.admin.command("ping")
    print("MongoDB connected successfully.")
except Exception as error:
    print("MongoDB connection failed:")
    print(error)