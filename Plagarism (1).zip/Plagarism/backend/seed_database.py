from database import reference_collection

REFERENCE_DOCUMENTS = [
    {
        "reference_id": "REF001",
        "title": "Machine Learning Fundamentals",
        "category": "Machine Learning",
        "text": """
        Machine learning is a branch of artificial intelligence that
        allows computers to learn from data without being explicitly
        programmed. Machine learning algorithms identify patterns in
        data and use those patterns to make predictions or decisions.
        It is widely used in healthcare, finance, education and many
        other fields.
        """
    },

    {
        "reference_id": "REF002",
        "title": "Artificial Intelligence Fundamentals",
        "category": "Artificial Intelligence",
        "text": """
        Artificial intelligence enables machines to perform tasks that
        normally require human intelligence. These tasks include
        learning, reasoning, problem solving, understanding language
        and making decisions. AI systems are increasingly used in
        modern applications and intelligent technologies.
        """
    },

    {
        "reference_id": "REF003",
        "title": "Cybersecurity Fundamentals",
        "category": "Cybersecurity",
        "text": """
        Cybersecurity protects computer systems, networks and data
        from unauthorized access and malicious attacks. Common
        cybersecurity threats include malware, phishing, ransomware,
        password attacks and social engineering. Security practices
        help organizations protect confidential information.
        """
    },

    {
        "reference_id": "REF004",
        "title": "Cloud Computing",
        "category": "Cloud Computing",
        "text": """
        Cloud computing provides computing resources such as servers,
        storage, databases and software through the internet. Cloud
        services allow organizations to access resources whenever
        required without maintaining all physical infrastructure.
        Cloud computing improves scalability, flexibility and resource
        management.
        """
    },

    {
        "reference_id": "REF005",
        "title": "Data Science",
        "category": "Data Science",
        "text": """
        Data science combines statistics, programming and machine
        learning to extract useful information from data. Data
        scientists collect, clean and analyze datasets to identify
        patterns and support decision making. Data visualization helps
        communicate important findings clearly.
        """
    },

    {
        "reference_id": "REF006",
        "title": "Database Management Systems",
        "category": "DBMS",
        "text": """
        A database management system is software used to store,
        organize and retrieve data efficiently. Database systems
        provide mechanisms for inserting, updating, deleting and
        querying information. Relational databases store information
        in tables containing rows and columns.
        """
    },

    {
        "reference_id": "REF007",
        "title": "Web Development",
        "category": "Web Development",
        "text": """
        Web development involves creating websites and web
        applications using technologies such as HTML, CSS and
        JavaScript. HTML provides the structure of a web page, CSS
        controls its appearance and JavaScript provides interactive
        functionality. Modern web applications can communicate with
        backend servers and databases.
        """
    },

    {
        "reference_id": "REF008",
        "title": "Internet of Things",
        "category": "IoT",
        "text": """
        The Internet of Things connects physical devices to the
        internet so that they can collect and exchange data. IoT
        devices commonly use sensors to monitor environmental
        conditions and send information to cloud or computing
        platforms. IoT is used in smart homes, healthcare,
        agriculture and industrial systems.
        """
    },

    {
        "reference_id": "REF009",
        "title": "Computer Networks",
        "category": "Computer Networks",
        "text": """
        A computer network connects multiple devices so that they
        can communicate and share resources. Networks use protocols
        to control how data is transmitted between devices. Common
        networking concepts include IP addresses, routers, switches,
        Ethernet and wireless communication.
        """
    },

    {
        "reference_id": "REF010",
        "title": "Software Engineering",
        "category": "Software Engineering",
        "text": """
        Software engineering is the systematic process of designing,
        developing, testing and maintaining software applications.
        The software development life cycle includes requirements
        analysis, design, implementation, testing and maintenance.
        Good software engineering practices improve reliability and
        maintainability.
        """
    }
]


# Remove old reference documents
reference_collection.delete_many({})


# Insert the 10 reference documents
result = reference_collection.insert_many(REFERENCE_DOCUMENTS)


print()
print("======================================")
print("REFERENCE DATABASE CREATED")
print("======================================")
print("Documents inserted:", len(result.inserted_ids))
print()

for document in REFERENCE_DOCUMENTS:
    print(
        document["reference_id"],
        "-",
        document["title"]
    )

print()
print("Database seeding completed.")